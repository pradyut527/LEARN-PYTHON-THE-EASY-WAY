text="hello world"
print(len(text.split()))