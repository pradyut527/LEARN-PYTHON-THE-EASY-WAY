class A:
    pass