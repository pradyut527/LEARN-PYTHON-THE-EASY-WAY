age=10
if age>=7: print("OK")