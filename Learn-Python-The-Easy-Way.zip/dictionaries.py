d={"name":"Alice"}
print(d)