import random
n=random.randint(1,10)
print(n)