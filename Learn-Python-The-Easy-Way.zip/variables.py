name="Alice"
age=12
print(name, age)