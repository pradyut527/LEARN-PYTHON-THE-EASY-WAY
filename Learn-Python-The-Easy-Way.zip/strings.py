text="Python"
print(text[0:3])