colors=("red","green")
print(colors)