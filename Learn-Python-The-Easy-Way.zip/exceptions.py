try: int("x")
except: print("error")