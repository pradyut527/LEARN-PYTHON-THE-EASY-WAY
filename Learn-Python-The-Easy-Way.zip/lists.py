fruits=["apple","banana"]
print(fruits)